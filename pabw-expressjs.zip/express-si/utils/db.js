const mysql = require('mysql2');

// KONEKSI
const db = mysql.createConnection({
   host: 'localhost',
   user: 'cal',
   password: '300800',
   database: 'pabw'
});

// CEK KONEKSI
db.connect((e) => {
   if (e) {
      console.error('Gagal terkoneksi ke database');
      return;
   }

   console.log('Koneksi Berhasil!');

})

module.exports = { db }