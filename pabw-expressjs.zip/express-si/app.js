const express = require('express')
const app = express()
const port = 8080
const crypto = require("crypto");
const { db } = require('./utils/db');
const { title } = require('process');
// const bodyParser = require('body-parser');
const session = require('express-session');

// Jika nama file views ber extensi html
// app.engine('html', require('ejs').renderFile);

// EJS View Engine
app.set('view engine', 'ejs');

// MIDDLEWARE
// STATIC FOLDER ACCESS
app.use(express.static('public'));
app.use(express.urlencoded());
// app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
   secret: 'tugasPABW',
   resave: false,
   saveUninitialized: true
}));

// Kunci rahasia untuk enkripsi
const secretKey = "123tugaspabw";

// ENCRYPT DATA
function encryptId(id) {
   const cipher = crypto.createCipheriv(
      "aes-256-cbc",
      crypto.createHash("sha256").update(secretKey).digest(),
      Buffer.alloc(16, 0) // IV
   );
   let encrypted = cipher.update(id.toString(), "utf8", "base64");
   encrypted += cipher.final("base64");

   return encrypted.replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
}

// DECRYPT DATA
function decryptId(encryptedId) {
   let encryptedBase64 = encryptedId.replace(/-/g, "+").replace(/_/g, "/");

   // Menambahkan padding jika diperlukan
   const padding = encryptedBase64.length % 4;
   if (padding) {
      encryptedBase64 += "=".repeat(4 - padding); // Menambahkan padding
   }

   const decipher = crypto.createDecipheriv(
      "aes-256-cbc",
      crypto.createHash("sha256").update(secretKey).digest(),
      Buffer.alloc(16, 0) // IV yang sama
   );
   let decrypted = decipher.update(encryptedBase64, "base64", "utf8");
   decrypted += decipher.final("utf8");

   return decrypted;
}

// DASHBOARD PAGE
app.get(['/', '/home', '/dashboard'], (req, res) => {
   if (!req.session.user) {
      res.redirect('/login');
   }

   // GET SESSION
   let userSess = req.session.user;
   let query;

   if (userSess.role !== '1') {
      query = `SELECT * FROM comments WHERE uid = ${userSess.uid}`;
   } else {
      query = `SELECT * FROM comments`;
   }

   db.query(query, (err, results) => {
      if (err) {
         console.error("Error mengambil data:", err.message);
         res.status(500).json({ message: "Error mengambil data" });
         return;
      }

      const comments = results;
      const dataSafe = comments.map((comment) => ({
         ...comment,
         comment: decryptId(comment.comment),
         id: encryptId(comment.id),
         reply: comment.reply ? decryptId(comment.reply) : 'Belum ada balasan',
      }));

      let data = {
         title: 'Dashboard',
         comments: dataSafe,
         role: userSess.role,
         username: userSess.username,
         email: userSess.email
      }

      res.render('dash/index', data);
   });

})

app.get('/addComment', (req, res) => {
   if (!req.session.user) {
      res.redirect('/login');
   }

   // GET SESSION
   let userSess = req.session.user;

   let data = {
      title: 'Tambah Laporan',
      role: userSess.role,
      username: userSess.username,
      email: userSess.email
   }
   res.render('add/comment', data);
})

app.post('/addComment', (req, res) => {
   // GET SESSION
   let userSess = req.session.user;
   let data = [
      userSess.uid,
      userSess.username,
      encryptId(req.body.message),
      '2025-01-01',
      ''
   ];

   const query = "INSERT INTO comments (uid, nama, comment, tgl, reply) VALUES (?, ?, ?, ?, ?)";
   db.query(query, data, (e) => {
      if (e) {
         console.error("Error menambahkan data:", e.message);
         res.status(500).json({ message: "Error menambahkan data" });
         return;
      }
      res.redirect('/');
   });
})

app.get('/replyUser/:id', (req, res) => {
   if (!req.session.user) {
      res.redirect('/login');
   }
   // GET SESSION
   let userSess = req.session.user;
   let idComment = decryptId(req.params.id);

   const query = "SELECT * FROM comments JOIN users ON comments.uid = users.id WHERE comments.id = ?";
   db.query(query, [idComment], (e, results) => {
      if (e) {
         console.error("Error mengambil data:", e.message);
         res.status(500).json({ message: "Error mengambil data" });
         return;
      }

      results = results.map((comment) => ({
         ...comment,
         comment: decryptId(comment.comment)
      }));

      let data = {
         title: 'Balas Laporan',
         role: userSess.roleId,
         username: userSess.username,
         email: userSess.email,
         results: results[0],
         idComment: encryptId(idComment),
      }

      res.render('add/replyUser', data);
   })
})

app.post('/replyUser/:id', (req, res) => {
   let id = decryptId(req.params.id);
   let replies = encryptId(req.body.message);

   const query = "UPDATE comments SET reply = ? WHERE id = ?";
   db.query(query, [replies, id], (e) => {
      if (e) {
         console.error('Data Gagal Ditambahkan', e.message);
         return;
      }

      res.redirect('/');
   });
})

app.get('/delcomments/:id', (req, res) => {
   let id = decryptId(req.params.id);

   const query = "DELETE FROM comments WHERE id = ?";

   db.query(query, [id], (e) => {
      if (e) {
         console.error('Data Gagal Dihapus');
         return;
      }

      res.redirect('/');
   });
})

// AUTH PAGE
app.get('/login', (req, res) => {
   if (req.session.user) {
      res.redirect('/dashboard');
   }

   let data = {
      title: 'Login',
      message: req.query.message ? req.query.message : ''
   }

   res.render('auth/index', data);
})

app.post('/login', (req, res) => {
   let udata = [
      req.body.email
   ];

   const query = "SELECT * FROM users WHERE email = ?";
   db.query(query, udata, (e, results) => {
      if (e) {
         console.error('Gagal Login', e.message);
         return;
      }

      results = results.map((user) => ({
         ...user,
         passwd: decryptId(user.passwd)
      }));

      if (results.length === 0 || results[0].passwd !== req.body.passwd) {
         let data = {
            message: 'Email atau Password Salah'
         }
         res.redirect(`/login?message=${data.message}`);
         return;
      }

      req.session.user = {
         uid: results[0].id,
         username: results[0].username,
         email: results[0].email,
         role: JSON.stringify(results[0].roleid),
      }

      res.redirect('/');
   })
})

app.get('/register', (req, res) => {
   if (req.session.user) {
      res.redirect('/dashboard');
   }

   let data = {
      title: 'Register',
      message: req.query.message ? req.query.message : ''
   }

   res.render('auth/reg', data);
})

app.post('/register', (req, res) => {
   if (req.body.passwd !== req.body.confirmPasswd) {
      let data = {
         title: 'Register',
         message: 'Password Tidak Sama'
      }
      res.redirect(`/register?message=${data.message}`);
      return;
   }

   let datauser = [
      req.body.nama,
      req.body.email,
      encryptId(req.body.passwd),
      2
   ];

   const query = "INSERT INTO users (username, email, passwd, roleid) VALUES (?, ?, ?, ?)";
   db.query(query, datauser, (e) => {
      if (e) {
         console.error("Error menambahkan data:", e.message);
         res.status(500).json({ message: "Error menambahkan data" });
         return;
      }
      let data = {
         message: 'Registrasi Berhasil, Silahkan Login'
      }
      res.redirect(`/login?message=${data.message}`);
   });
})

app.get('/logout', (req, res) => {
   req.session.destroy();
   res.redirect('/login');
})

app.use('/', (req, res) => {
   res.status(404);
   res.render('404/index');
})

app.listen(port, () => {
   console.log(`Example app listening on port ${port}`)
})